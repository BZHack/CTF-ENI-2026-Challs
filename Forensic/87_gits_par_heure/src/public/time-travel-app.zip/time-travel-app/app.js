// Machine Temporelle - Application principale
console.log('Machine Temporelle initialisée');
console.log('Année cible: 1955');
